import torch
from torch import nn
import math
import copy


class PositionalEncoding(nn.Module):
    "Implement the PE function."

    def __init__(self, d_model, dropout, max_len=5000):
        super(PositionalEncoding, self).__init__()
        self.dropout = nn.Dropout(p=dropout)
        # Compute the positional encodings once in log space.
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2) *
                             -(math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        pe = pe.unsqueeze(0)
        self.register_buffer('pe', pe)

    def forward(self, x):
        x = x + self.pe[:, :x.size(1)]
        return self.dropout(x)


class Encoder(nn.Module):
    def __init__(self, input_dim, d_model, n_heads=8, n_layers=6, dropout=0.1):
        super(Encoder, self).__init__()

        self.d_model = d_model
        self.input_dim = input_dim

        # observation embeddings
        self.embeddings = nn.Sequential(nn.Linear(input_dim, d_model),
                                        PositionalEncoding(d_model, dropout) if dropout > 0 else nn.Identity())

        # feed the instance projection to Transformer.Encoder to capture their hidden correlation
        assert d_model % n_heads == 0
        layer = nn.TransformerEncoderLayer(d_model=d_model, nhead=n_heads, batch_first=True, dropout=dropout)
        self.layers = nn.ModuleList([copy.deepcopy(layer) for _ in range(n_layers)])

        # map the hidden features to scores
        self.proj = nn.Sequential(nn.Linear(d_model, 1),
                                  nn.Flatten())




        # initialize the model weight
        self.weight_init()

    def weight_init(self):
        for m in self.modules():
            if isinstance(m, (torch.nn.Linear, torch.nn.Conv1d, torch.nn.Conv2d)):
                nn.init.xavier_normal_(m.weight)
                nn.init.constant_(m.bias, 0)

    def forward(self, x, src_mask=None):
        # observation embeddings
        features = self.embeddings(x)
        # features: B x L x size
        for layer in self.layers:
            features = layer(features, src_key_padding_mask=src_mask)
        # B x L
        scores = self.proj(features)
        return scores
