import torch
import copy

'''
sample a permutation \pi from a permutation distribution  p(\pi|s) 
'''


class Sampler:
    def __init__(self, temperature, sample_iters, beta):
        self.T = temperature
        self.sample_iters = sample_iters
        self.beta = beta

    def sample(self, num_samples, scores, src_mask=None):
        # num_samples x B x L
        pers = torch.stack([self.gibbs_sampling(scores, src_mask)
                            for _ in range(num_samples)])
        #  num_samples x B x L
        return pers

    def update(self):
        self.T = self.T * self.beta

    def gibbs_sampling(self, scores, src_mask=None):
        with torch.no_grad():
            if src_mask is not None:
                scores.masked_fill_(src_mask, -1e9)

            batch_size, seq_len = scores.size(0), scores.size(1)

            # generate the initial solution (alpha) via the descending order of the ranking scores
            # B x L
            ranks = torch.sum(scores.unsqueeze(-1) < scores.unsqueeze(1), dim=-1)
            # update the  solution (alpha) iteratively via gibbs sampling
            batch_index = torch.arange(batch_size).to(ranks.device)
            for _ in range(self.sample_iters):
                for i in range(seq_len - 1, 0, -1):
                    a, s = ranks[:, i], scores[:, i]
                    swap_pos = (i * torch.rand(batch_size)).long().to(ranks.device)
                    swap_alpha = ranks[batch_index, swap_pos]
                    swap_score = scores[batch_index, swap_pos]
                    swap_prob = 1.0 / (1.0 + torch.exp(-(a - swap_alpha) * (s - swap_score) / self.T))

                    # filter the candidates that should be exchanged
                    accepted = torch.rand(batch_size).to(ranks.device) < swap_prob

                    rows, cols = batch_index[accepted], swap_pos[accepted]

                    # exchange their permutation (or ranking order ) alpha
                    ranks[rows, cols], ranks[rows, i] = ranks[rows, i], ranks[rows, cols]
        return ranks


'''
randomly generate Permutation as negative examples
'''


class RandomSampler(Sampler):
    def __init__(self, temperature, sample_iters, beta):
        super().__init__(temperature, sample_iters, beta)

    def gibbs_sampling(self, scores, src_mask=None):
        batch_size, seq_len = scores.size(0), scores.size(1)
        lens = torch.sum(~src_mask, dim=-1) if src_mask is not None else [seq_len] * batch_size
        # B x L
        ranks = torch.as_tensor(
            [torch.randperm(t).tolist() + [t] * (seq_len - t) for t in lens], dtype=torch.int32).to(scores.device)

        return ranks


'''
generate negative permutations by randomly shuffle the scores
'''


class NegativeSampler(Sampler):
    def __init__(self, temperature, sample_iters, beta):
        super().__init__(temperature, sample_iters, beta)

    # shuffle the scores
    def gibbs_sampling(self, scores, src_mask=None):
        with torch.no_grad():
            # B x L
            positions = RandomSampler().gibbs_sampling(scores, src_mask)
            # shuffle the scores according to the ranks (positions)
            negs = scores.scatter(1, positions, scores)

            return super().gibbs_sampling(negs, src_mask)


class ActorLoss:
    def __init__(self, positive_sampler, negative_sampler):
        self.positive_sampler = positive_sampler
        self.negative_sampler = negative_sampler

    def __call__(self, neg_nums, scores, advantage, src_mask=None, used_prev_action=None):
        # 1 x B x L
        pos = used_prev_action if used_prev_action is not None else \
            self.positive_sampler.sample(1, scores, src_mask)
        # k x B x L
        neg = self.negative_sampler.sample(neg_nums, scores, src_mask)

        seq_len = scores.size(1)
        if src_mask is not None:
            scores.masked_fill_(src_mask, 0.0)
            # 1 x B x 1
            seq_len = torch.sum(~src_mask, dim=-1, keepdim=True).unsqueeze(0)

        pos = 2 * (seq_len - pos) / (seq_len * (seq_len + 1.0))
        neg = 2 * (seq_len - neg) / (seq_len * (seq_len + 1.0))
        # 1 x B x L
        scores = scores.unsqueeze(0)

        relative = torch.sum(scores * pos, dim=[0, -1]) - \
                   1.0 / neg_nums * torch.sum(scores * neg, dim=[0, -1])

        loss = torch.mean(advantage.squeeze(-1) * relative)

        self.positive_sampler.update()
        self.negative_sampler.update()

        return loss
