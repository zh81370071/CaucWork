import torch
import numpy as np


class ReplayBuffer():
    """Buffer to store environment transitions."""

    def __init__(self, capacity, obs_shape, device):
        self.capacity = capacity
        self.device = device
        self.obses = np.empty((capacity, *obs_shape), dtype=np.float32)
        self.next_obses = np.empty((capacity, *obs_shape), dtype=np.float32)
        self.actions = np.empty((capacity, obs_shape[0]), dtype=np.float32)
        self.rewards = np.empty((capacity, 1), dtype=np.float32)
        self.masks = np.empty((capacity, obs_shape[0]), dtype=np.bool)

        self.idx = 0
        self.full = False

    def __len__(self):
        return self.capacity if self.full else self.idx

    def add(self, state, action, reward, next_state):
        (obs, mask), (next_obs, _) = state, next_state

        for (o, a, r, n, m) in zip(*list(map(lambda t: torch.chunk(t, obs.size(0)),
                                             [obs, action, reward, next_obs, mask]))):
            np.copyto(self.obses[self.idx], o.data.cpu())
            np.copyto(self.actions[self.idx], a.data.cpu())
            np.copyto(self.rewards[self.idx], r.data.cpu())
            np.copyto(self.next_obses[self.idx], n.data.cpu())
            np.copyto(self.masks[self.idx], m.data.cpu())

            self.idx = (self.idx + 1) % self.capacity
            self.full = self.full or self.idx == 0

    def sample(self, batch_size):
        idxs = np.random.randint(0,
                                 self.capacity if self.full else self.idx,
                                 size=batch_size, dtype=np.int)

        obs = torch.as_tensor(self.obses[idxs], device=self.device, dtype=torch.float32)
        action = torch.as_tensor(self.actions[idxs], device=self.device, dtype=torch.int32)
        reward = torch.as_tensor(self.rewards[idxs], device=self.device, dtype=torch.float32)
        next_obs = torch.as_tensor(self.next_obses[idxs], device=self.device, dtype=torch.float32)
        mask = torch.as_tensor(self.masks[idxs], device=self.device, dtype=torch.bool)

        return (obs, mask), action, reward, (next_obs, mask)
