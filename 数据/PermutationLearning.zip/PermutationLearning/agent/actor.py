from torch import nn
import torch


class Actor(nn.Module):
    def __init__(self, encoder):
        super(Actor, self).__init__()
        self.encoder = encoder

    def forward(self, x):
        obs, masked = x
        scores = self.encoder(obs, masked)
        # normalize the scores by subtracting the mean
        mean = torch.sum(scores * ~masked, dim=-1, keepdim=True)/torch.sum(~masked, dim=-1, keepdim=True)
        return scores - mean

