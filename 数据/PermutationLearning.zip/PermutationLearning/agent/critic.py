import torch
from torch import nn
import copy


class Critic(nn.Module):
    def __init__(self, encoder):
        super(Critic, self).__init__()
        self.v1_net = copy.deepcopy(encoder)
        self.v2_net = copy.deepcopy(encoder)
        # put the cls token at the beginning of the sequence
        self.cls_token = nn.Parameter(torch.randn(1, 1, encoder.input_dim))

        # re-initialize the model parameters
        self.v1_net.weight_init()
        self.v2_net.weight_init()
        nn.init.xavier_normal_(self.cls_token)

    def forward(self, x):
        x, src_mask = x
        batch, seq_len = x.shape[0], x.shape[1]
        # 连接第一个token
        x = torch.cat((self.cls_token.expand(batch, -1, -1), x), dim=1)
        # 在src_mask第一列补充True
        head = torch.ones(batch, 1).bool().to(x.device)
        src_mask = torch.cat((head, src_mask), dim=-1)
        # 第一个token位置的分数, normalize the length of sequence
        v1 = self.v1_net(x, src_mask)[:, 0]/torch.sum(~src_mask, dim=-1)
        v2 = self.v2_net(x, src_mask)[:, 0]/torch.sum(~src_mask, dim=-1)
        return v1.unsqueeze(-1), v2.unsqueeze(-1)
