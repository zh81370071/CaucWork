import torch
import copy
import torch.nn.functional as F


class StochasticAgent():
    def __init__(self, actor, critic, actor_loss,
                 neg_nums, discount, device,
                 actor_lr, actor_betas, actor_update_frequency,
                 critic_lr, critic_betas, critic_tau, critic_target_update_frequency):
        super().__init__()
        self.device = torch.device(device)
        self.neg_nums = neg_nums

        # initialize the actor
        self.actor = actor.to(self.device)
        self.actor_update_frequency = actor_update_frequency
        self.actor_loss = actor_loss

        # initialize the critic and target critic
        self.critic = critic.to(self.device)
        self.critic_target = copy.deepcopy(self.critic)
        self.critic_tau = critic_tau
        self.critic_target_update_frequency = critic_target_update_frequency
        self.discount = discount

        # optimizers
        self.actor_optimizer = torch.optim.Adam(self.actor.parameters(),
                                                lr=actor_lr,
                                                betas=actor_betas)

        self.critic_optimizer = torch.optim.Adam(self.critic.parameters(),
                                                 lr=critic_lr,
                                                 betas=critic_betas)
        self.train()

    def train(self, training=True):
        self.actor.train(training)
        self.critic.train(training)

    def act(self, state):
        obs, src_mask = state
        scores = self.actor(state)
        return self.actor_loss.positive_sampler.sample(1, scores, src_mask).squeeze(0)

    def update_critic(self, experience, logger, step):
        obs, action, reward, next_obs = experience
        target_v1, target_v2 = self.critic_target(next_obs)
        target_V = reward + self.discount * torch.min(target_v1, target_v2)
        target_V = target_V.detach()

        # get current V estimates
        current_v1, _ = self.critic(obs)
        critic_loss = F.mse_loss(current_v1, target_V)
        logger.log('train/critic_loss', critic_loss, step)

        # Optimize the critic
        self.critic_optimizer.zero_grad()
        critic_loss.backward()
        torch.nn.utils.clip_grad_norm_(self.critic.parameters(), max_norm=1.0, norm_type=2)
        self.critic_optimizer.step()

    def update_actor(self, experience, logger, step):
        obs, action, reward, next_obs = experience
        scores = self.actor(obs)
        current_v1, _ = self.critic(obs)
        # Q(st,at) -> v(st+1)
        next_v1, _ = self.critic(next_obs)
        advantage = (reward + self.discount * next_v1 - current_v1).detach()

        actor_loss = self.actor_loss(self.neg_nums, scores, -advantage, obs[1], action.unsqueeze(0))
        # record the loss
        logger.log('train/actor_loss', actor_loss, step)
        # optimize the actor
        self.actor_optimizer.zero_grad()
        actor_loss.backward()
        torch.nn.utils.clip_grad_norm_(self.actor.parameters(), max_norm=1.0)
        self.actor_optimizer.step()

    def update(self, experience, logger, step):
        # update the critic
        self.update_critic(experience, logger, step)
        if step % self.actor_update_frequency == 0:
            self.update_actor(experience, logger, step)

        if step % self.critic_target_update_frequency == 0:
            self.soft_update_params(self.critic, self.critic_target, self.critic_tau)

    def soft_update_params(self, net, target_net, tau):
        for param, target_param in zip(net.parameters(), target_net.parameters()):
            target_param.data.copy_(tau * param.data +
                                    (1 - tau) * target_param.data)
