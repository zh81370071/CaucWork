import torch
import numpy as np
import random
import hydra

from utils.replayBuffer import ReplayBuffer
from utils.logger import Logger
import time


class Workspace:
    def __init__(self, cfg):
        self.logger = Logger(hydra.core.hydra_config.HydraConfig.get().runtime.output_dir)
        self.cfg = cfg
        self.device = cfg.device
        self.set_seed(cfg.seed)
        self.env = hydra.utils.instantiate(cfg.env)
        self.agent = hydra.utils.instantiate(cfg.agent)
        self.replay_buffer = ReplayBuffer(int(cfg.replay_buffer_capacity),
                                          (cfg.env.dataset.max_nodes, cfg.env.dataset.size),
                                          self.device)
        self.step = 0

    def set_seed(self, seed):
        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)
        np.random.seed(seed)
        random.seed(seed)

    def run(self):
        # run the ${episodes} epochs

        for epoch in range(self.cfg.episodes):
            # learn permutation with respect to each batch (or num of samples)
            for batch in self.env.reset():
                # record the episode reward, cost and time
                results = self.act(batch)
                self._record(*results)

            # evaluate the model
            for batch in self.env.reset(training=False):
                # record the episode reward, time
                with torch.no_grad():
                    results = self.act(batch, training=False)
                    self._record(*results)

            # dump the loss for each batch
            self.logger.dump(epoch)

    def act(self, obs, training=True):
        self.agent.train(training)
        # the cost for the initial solution
        episode_reward, cost = [], self.env.reward(obs)
        # the starting time
        start_time = time.time()
        # iteratively update the permutation
        for _ in range(self.cfg.episode_steps):
            # the agent/policy yield the action for the specific observation
            action = self.agent.act(obs)
            # the environment receive the action, and then return its corresponding reward and the next state
            next_obs, reward = self.env.step(obs, action)
            if training:
                # store the experience
                self.replay_buffer.add(obs, action, reward, next_obs)
                # update the agent according to history experience
                self.agent.update(self.replay_buffer.sample(self.cfg.batch_size), self.logger, self.step)
                # update the step
                self.step = self.step + 1
            # shift to the next state
            obs = next_obs
            # accumulate the reward
            episode_reward.append(reward)
        return episode_reward, cost, time.time() - start_time

    def _record(self, rs, cost, interval, training=True):
        # record the average improved ratio
        rs = torch.cumsum(torch.stack(rs), dim=0)
        ratio = rs / (cost + 1e-5)
        # improving ratio
        mode = 'train' if training else 'eval'
        self.logger.log(f'{mode}/episode_reward', torch.mean(cost - rs[-1, :]), self.step)
        self.logger.log(f'{mode}/episode_dist', torch.mean(cost), self.step)
        self.logger.log(f'{mode}/duration', interval, self.step)
        self.logger.log(f'{mode}/mean_ratio', torch.mean(ratio), self.step)
        self.logger.log(f'{mode}/ending_ratio', torch.mean(ratio[-1, :]), self.step)


@hydra.main(version_base=None, config_path='config', config_name='conf.yaml')
def main(cfg):
    workspace = Workspace(cfg)
    workspace.run()



if __name__ == '__main__':
    main()
