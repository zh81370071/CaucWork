import torch
from torch.utils.data import Dataset, DataLoader, random_split


class TSPDataset(Dataset):
    def __init__(self, num_samples=1e6, max_nodes=50, size=2):
        super(TSPDataset, self).__init__()
        dataset = torch.rand(num_samples, max_nodes, size)
        lens = ( 4 + torch.rand(num_samples, 1) * ( max_nodes-3) ).long()
        masked = torch.arange(max_nodes) >= lens
        # fill the padding with zero rows
        self.dataset = dataset.masked_fill_(masked.unsqueeze(-1).expand_as(dataset), 0)
        self.masked = masked

    def __len__(self):
        return self.dataset.size(0)

    def __getitem__(self, idx):
        return self.dataset[idx], self.masked[idx]


class TSPEnv:
    def __init__(self, dataset, batch_size, split_ratio, device):
        # divide the dataset into train set and test set
        train_size = int(split_ratio * len(dataset))
        eval_size = len(dataset) - train_size
        train_set, eval_set = random_split(dataset, [train_size, eval_size])
        # data loaders for two datasets
        self.train_dataloader = DataLoader(train_set, batch_size=batch_size, shuffle=True)
        self.eval_dataloader = DataLoader(eval_set, batch_size=batch_size, shuffle=True)
        self.device = device

    def reset(self, training=True):
        # pick the dataloader
        loader = self.train_dataloader if training else self.eval_dataloader
        # yield the data
        for (obs, masked) in loader:
            yield obs.to(self.device), masked.to(self.device)

    def step(self, state, action):
        # current state
        obs, masked = state
        # next obs: shuffle the current observation according to the action
        next_obs = obs.scatter(1, action.long().unsqueeze(-1).expand_as(obs), obs)

        # return the reward: r(s(t+1)) - r(s(t))
        reward = self.reward(state) - self.reward((next_obs, masked))

        return (next_obs, masked), reward

    def reward(self, state):

        obs, masked = state
        # travel cost: distance from 1->2->...->n
        travel = (obs[:, 1:] - obs[:, :-1]).norm(p=2, dim=-1) * (~masked[:, 1:])
        # circle cost: distance from n->1
        batch_size, lens = obs.size(0), torch.sum(~masked, dim=-1)
        circle = (obs[:, 0] - obs[torch.arange(batch_size).to(self.device), lens - 1]).norm(p=2, dim=-1)

        # normalize the number of paths in each tsp case
        return (torch.sum(travel, dim=-1) + circle)/ (torch.sum(~masked, dim=-1) + 1e-5)